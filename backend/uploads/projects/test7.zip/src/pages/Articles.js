import React from 'react';

export const Articles = () => {
  return <div>Articles Page</div>;
};